package com.example.lib;

/**
 * Created by Anna on 4/15/2018.
 */

public interface IControl {
}
